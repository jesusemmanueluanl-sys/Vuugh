package com.example.runner;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RunnerMod implements ModInitializer {
    public static final String MOD_ID = "runner";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static RunnerConfig config;
    public static Lang lang;
    public static GameManager game;

    @Override
    public void onInitialize() {
        config = RunnerConfig.load();
        lang = new Lang();
        lang.load(config.language);
        game = new GameManager(config, lang);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                RunnerCommands.register(dispatcher, game));

        ServerLifecycleEvents.SERVER_STARTED.register(game::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPING.register(game::onServerStopping);
        ServerTickEvents.END_SERVER_TICK.register(game::onTick);
        ServerLivingEntityEvents.AFTER_DEATH.register(game::onDeath);
        ServerPlayerEvents.AFTER_RESPAWN.register(game::onRespawn);
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register(game::onChangeWorld);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> game.onJoin(handler.player));
        PlayerBlockBreakEvents.BEFORE.register(game::onBlockBreak);
        UseItemCallback.EVENT.register(game::onUseItem);

        LOGGER.info(lang.get("plugin.enabled"));
    }
}
