package com.example.runner;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Equivalent of LanguageManager: loads ru/en strings from config/runner/lang.json (editable). */
public class Lang {
    private final Map<String, String> tr = new HashMap<>();

    public void load(String language) {
        tr.clear();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("runner").resolve("lang.json");
        try {
            String bundled;
            try (InputStream in = Lang.class.getResourceAsStream("/runner_lang.json")) {
                bundled = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            Files.createDirectories(file.getParent());
            if (!Files.exists(file)) {
                Files.writeString(file, bundled, StandardCharsets.UTF_8);
            }
            merge(bundled, "en");
            merge(bundled, language);
            merge(Files.readString(file, StandardCharsets.UTF_8), language);
        } catch (Exception e) {
            RunnerMod.LOGGER.error("Failed to load language file!", e);
        }
    }

    private void merge(String json, String language) {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (root.has(language)) {
            for (var e : root.getAsJsonObject(language).entrySet()) {
                tr.put(e.getKey(), e.getValue().getAsString());
            }
        }
    }

    public String get(String key) {
        return tr.getOrDefault(key, key);
    }

    public String get(String key, Map<String, String> placeholders) {
        String s = get(key);
        for (var e : placeholders.entrySet()) {
            s = s.replace("{" + e.getKey() + "}", e.getValue());
        }
        return s;
    }

    public String get(String key, String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return get(key, m);
    }
}
