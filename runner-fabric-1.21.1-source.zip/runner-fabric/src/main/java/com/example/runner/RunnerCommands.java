package com.example.runner;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/** /speedrunner (alias /sr): runner | hunter | start | stop | setup | compass */
public class RunnerCommands {
    private static GameManager game;
    private static RunnerConfig config;
    private static Lang lang;

    private static boolean isOp(ServerCommandSource src) {
        return src.hasPermissionLevel(2);
    }

    private static Text msg(String s, Formatting f) {
        return Text.literal(s).formatted(f);
    }

    private static void feedback(CommandContext<ServerCommandSource> ctx, String s, Formatting f) {
        ctx.getSource().sendFeedback(() -> msg(s, f), false);
    }

    private static int error(CommandContext<ServerCommandSource> ctx, String key) {
        ctx.getSource().sendError(msg(lang.get(key), Formatting.RED));
        return 0;
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher, GameManager gm) {
        game = gm;
        config = RunnerMod.config;
        lang = RunnerMod.lang;

        LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("speedrunner")
                .executes(RunnerCommands::help)
                .then(CommandManager.literal("help").executes(RunnerCommands::help))

                .then(CommandManager.literal("runner")
                        .requires(RunnerCommands::isOp)
                        .executes(ctx -> error(ctx, "runner.usage"))
                        .then(CommandManager.argument("player", EntityArgumentType.player())
                                .executes(ctx -> {
                                    game.assignRunner(EntityArgumentType.getPlayer(ctx, "player"));
                                    return 1;
                                })))

                .then(CommandManager.literal("hunter")
                        .requires(RunnerCommands::isOp)
                        .executes(ctx -> error(ctx, "hunter.usage"))
                        .then(CommandManager.argument("player", EntityArgumentType.player())
                                .executes(ctx -> {
                                    game.assignHunter(EntityArgumentType.getPlayer(ctx, "player"));
                                    return 1;
                                })))

                .then(CommandManager.literal("start")
                        .requires(RunnerCommands::isOp)
                        .executes(ctx -> {
                            if (game.isGameStarted()) return error(ctx, "game.already_started");
                            game.startGame();
                            return 1;
                        }))

                .then(CommandManager.literal("stop")
                        .requires(RunnerCommands::isOp)
                        .executes(ctx -> {
                            if (!game.isGameStarted()) return error(ctx, "game.not_started");
                            game.stopGame();
                            feedback(ctx, lang.get("game.stopped_by_admin"), Formatting.YELLOW);
                            return 1;
                        }))

                // Available to everybody; it only works for hunters (like the original).
                .then(CommandManager.literal("compass")
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p == null) return error(ctx, "command.player_only");
                            if (!game.isHunter(p.getUuid())) return error(ctx, "compass.not_hunter");
                            game.openCompassGui(p);
                            return 1;
                        }))

                .then(buildSetup());

        LiteralCommandNode<ServerCommandSource> node = dispatcher.register(root);
        dispatcher.register(CommandManager.literal("sr").executes(RunnerCommands::help).redirect(node));
    }

    private static int help(CommandContext<ServerCommandSource> ctx) {
        feedback(ctx, lang.get("help.header"), Formatting.GOLD);
        for (String k : new String[]{"help.runner", "help.hunter", "help.start", "help.stop", "help.compass",
                "help.setup_prep", "help.setup_goal", "help.setup_goal_adv", "help.setup_hearts"}) {
            feedback(ctx, lang.get(k), Formatting.YELLOW);
        }
        return 1;
    }

    private static LiteralArgumentBuilder<ServerCommandSource> buildSetup() {
        return CommandManager.literal("setup")
                .requires(RunnerCommands::isOp)
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(game::settingsHeader, false);
                    ctx.getSource().sendFeedback(game::settingsCurrent, false);
                    feedback(ctx, lang.get("setup.help_prep"), Formatting.YELLOW);
                    feedback(ctx, lang.get("setup.help_goal"), Formatting.YELLOW);
                    feedback(ctx, lang.get("setup.help_hearts"), Formatting.YELLOW);
                    return 1;
                })

                .then(CommandManager.literal("prep")
                        .then(CommandManager.argument("seconds", IntegerArgumentType.integer(0))
                                .executes(ctx -> {
                                    if (game.isGameStarted()) return error(ctx, "setup.game_running");
                                    int secs = IntegerArgumentType.getInteger(ctx, "seconds");
                                    config.prepTime = secs;
                                    config.save();
                                    feedback(ctx, lang.get("setup.prep_set", "time", String.valueOf(secs)), Formatting.GREEN);
                                    return 1;
                                })))

                .then(CommandManager.literal("goal")
                        .then(simpleGoal("dragon"))
                        .then(simpleGoal("nether"))
                        .then(simpleGoal("end"))
                        .then(CommandManager.literal("advancement")
                                .executes(ctx -> error(ctx, "setup.advancement_usage"))
                                .then(CommandManager.argument("id", IdentifierArgumentType.identifier())
                                        .suggests((ctx, builder) -> CommandSource.suggestIdentifiers(
                                                ctx.getSource().getServer().getAdvancementLoader().getAdvancements()
                                                        .stream().map(AdvancementEntry::id),
                                                builder))
                                        .executes(ctx -> {
                                            if (game.isGameStarted()) return error(ctx, "setup.game_running");
                                            Identifier id = IdentifierArgumentType.getIdentifier(ctx, "id");
                                            if (ctx.getSource().getServer().getAdvancementLoader().get(id) == null) {
                                                return error(ctx, "setup.advancement_not_found");
                                            }
                                            config.goal = "advancement";
                                            config.advancementGoal = id.toString();
                                            config.save();
                                            feedback(ctx, lang.get("setup.goal_set", "goal", "advancement (" + id + ")"),
                                                    Formatting.GREEN);
                                            return 1;
                                        }))))

                .then(CommandManager.literal("hearts")
                        .then(heartsRole("runner"))
                        .then(heartsRole("hunter")));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> simpleGoal(String goal) {
        return CommandManager.literal(goal).executes(ctx -> {
            if (game.isGameStarted()) return error(ctx, "setup.game_running");
            config.goal = goal;
            config.save();
            feedback(ctx, lang.get("setup.goal_set", "goal", goal), Formatting.GREEN);
            return 1;
        });
    }

    private static LiteralArgumentBuilder<ServerCommandSource> heartsRole(String role) {
        return CommandManager.literal(role)
                .then(CommandManager.argument("hearts", DoubleArgumentType.doubleArg(1.0, 512.0))
                        .executes(ctx -> {
                            if (game.isGameStarted()) return error(ctx, "setup.game_running");
                            double hearts = DoubleArgumentType.getDouble(ctx, "hearts");
                            if (role.equals("runner")) config.runnerHearts = hearts * 2.0;
                            else config.hunterHearts = hearts * 2.0;
                            config.save();
                            feedback(ctx, lang.get("setup.hearts_set",
                                    "role", lang.get("role." + role), "hearts", GameManager.trim(hearts)), Formatting.GREEN);
                            return 1;
                        }));
    }
}
