package com.example.runner;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LodestoneTrackerComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

import java.util.*;

/** Game state + logic (port of the Runner plugin's main class). */
public class GameManager {
    private static final String TRACKER_TAG = "runner_tracker";

    private final RunnerConfig config;
    private final Lang lang;
    private MinecraftServer server;

    private final Set<UUID> runners = new LinkedHashSet<>();
    private final Set<UUID> hunters = new LinkedHashSet<>();
    private final Set<UUID> deadRunners = new HashSet<>();
    private final Map<UUID, UUID> hunterTarget = new HashMap<>();
    private final Map<UUID, GlobalPos> lastLocations = new HashMap<>();
    private final Map<UUID, Map<RegistryKey<World>, BlockPos>> portalLocations = new HashMap<>();
    private final Map<UUID, Set<RegistryKey<World>>> visitedWorlds = new HashMap<>();
    private final Map<UUID, Vec3d> frozenPos = new HashMap<>();

    private boolean gameStarted;
    private boolean preparationPhase;
    private int prepTicksLeft;
    private long gameTicks;
    private ServerBossBar timerBar;

    public GameManager(RunnerConfig config, Lang lang) {
        this.config = config;
        this.lang = lang;
    }

    // ------------------------------------------------------------------ lifecycle

    public void onServerStarted(MinecraftServer s) {
        this.server = s;
    }

    public void onServerStopping(MinecraftServer s) {
        if (timerBar != null) {
            timerBar.clearPlayers();
            timerBar = null;
        }
        gameStarted = false;
        preparationPhase = false;
        runners.clear();
        hunters.clear();
        clearRuntime();
        RunnerMod.LOGGER.info(lang.get("plugin.disabled"));
    }

    private void clearRuntime() {
        deadRunners.clear();
        hunterTarget.clear();
        lastLocations.clear();
        portalLocations.clear();
        visitedWorlds.clear();
        frozenPos.clear();
    }

    // ------------------------------------------------------------------ helpers

    private static MutableText t(String s, Formatting f) {
        return Text.literal(s).formatted(f);
    }

    private void broadcast(Text text) {
        server.getPlayerManager().broadcast(text, false);
    }

    private ServerPlayerEntity player(UUID id) {
        return server.getPlayerManager().getPlayer(id);
    }

    private String nameOf(UUID id) {
        ServerPlayerEntity p = player(id);
        return p != null ? p.getName().getString() : id.toString();
    }

    public boolean isGameStarted() {
        return gameStarted;
    }

    public boolean isRunner(UUID id) {
        return runners.contains(id);
    }

    public boolean isHunter(UUID id) {
        return hunters.contains(id);
    }

    private boolean isAliveRunner(UUID id) {
        return runners.contains(id) && !deadRunners.contains(id);
    }

    private List<ServerPlayerEntity> aliveRunnerPlayers() {
        List<ServerPlayerEntity> list = new ArrayList<>();
        for (UUID id : runners) {
            if (deadRunners.contains(id)) continue;
            ServerPlayerEntity p = player(id);
            if (p != null) list.add(p);
        }
        return list;
    }

    private static String dimName(RegistryKey<World> key) {
        return key.getValue().getPath();
    }

    private static String formatLocation(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    private void sendTitle(ServerPlayerEntity p, Text title, Text subtitle, int fadeIn, int stay, int fadeOut) {
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(fadeIn, stay, fadeOut));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
        p.networkHandler.sendPacket(new TitleS2CPacket(title));
    }

    private void applyHearts(ServerPlayerEntity p, double hp) {
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (inst != null) {
            inst.setBaseValue(hp);
            p.setHealth((float) hp);
        }
    }

    private void applyRoleHearts(ServerPlayerEntity p) {
        if (runners.contains(p.getUuid())) applyHearts(p, config.runnerHearts);
        else if (hunters.contains(p.getUuid())) applyHearts(p, config.hunterHearts);
    }

    // ------------------------------------------------------------------ roles (commands)

    public void assignRunner(ServerPlayerEntity p) {
        runners.add(p.getUuid());
        hunters.remove(p.getUuid());
        broadcast(t(lang.get("runner.set", "player", p.getName().getString()), Formatting.GREEN));
    }

    public void assignHunter(ServerPlayerEntity p) {
        hunters.add(p.getUuid());
        runners.remove(p.getUuid());
        broadcast(t(lang.get("hunter.set", "player", p.getName().getString()), Formatting.GREEN));
        if (gameStarted) giveCompassToHunter(p);
    }

    // ------------------------------------------------------------------ start / stop

    public void startGame() {
        gameStarted = true;
        clearRuntime();
        gameTicks = 0;
        prepTicksLeft = Math.max(0, config.prepTime) * 20;
        preparationPhase = prepTicksLeft > 0;

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            if (runners.contains(id)) {
                applyHearts(p, config.runnerHearts);
                visitedWorlds.computeIfAbsent(id, k -> new HashSet<>()).add(p.getServerWorld().getRegistryKey());
                lastLocations.put(id, GlobalPos.create(p.getServerWorld().getRegistryKey(), p.getBlockPos()));
            } else if (hunters.contains(id)) {
                applyHearts(p, config.hunterHearts);
                giveCompassToHunter(p);
                frozenPos.put(id, p.getPos());
            }
        }
        if (!preparationPhase) startGameTimer();
    }

    private void startGameTimer() {
        gameTicks = 0;
        timerBar = new ServerBossBar(timerText(0), BossBar.Color.GREEN, BossBar.Style.PROGRESS);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) timerBar.addPlayer(p);
    }

    private Text timerText(long seconds) {
        String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
        return t(lang.get("game.timer", "time", time), Formatting.GREEN);
    }

    public void stopGame() {
        broadcast(t(lang.get("game.stopped"), Formatting.RED));
        endGame(lang.get("game.stopped"));
    }

    private void win() {
        endGame(lang.get("game.end_runner_win_" + config.goal));
    }

    private void endGame(String message) {
        if (!gameStarted) return;
        gameStarted = false;
        preparationPhase = false;

        Text title = t(lang.get("game.end"), Formatting.YELLOW);
        Text subtitle = t(message, Formatting.GOLD);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            sendTitle(p, title, subtitle, 10, 70, 20);
            p.sendMessage(subtitle, false);
            removeTrackers(p);
            p.removeStatusEffect(StatusEffects.SLOWNESS);
            if (runners.contains(id) || hunters.contains(id)) applyHearts(p, 20.0);
            if (deadRunners.contains(id)) p.changeGameMode(GameMode.SURVIVAL);
        }
        if (timerBar != null) {
            timerBar.clearPlayers();
            timerBar = null;
        }
        clearRuntime();
    }

    // ------------------------------------------------------------------ tick

    public void onTick(MinecraftServer s) {
        if (!gameStarted) return;
        if (preparationPhase) tickPrep();
        else tickGame();
    }

    private void tickPrep() {
        if (prepTicksLeft <= 0) {
            preparationPhase = false;
            for (UUID id : hunters) {
                ServerPlayerEntity p = player(id);
                if (p != null) p.removeStatusEffect(StatusEffects.SLOWNESS);
            }
            frozenPos.clear();
            startGameTimer();
            return;
        }
        if (prepTicksLeft % 20 == 0) {
            int secs = prepTicksLeft / 20;
            Text title = t(lang.get("game.preparation"), Formatting.YELLOW);
            Text sub = t(lang.get("game.preparation_time", "time", String.valueOf(secs)), Formatting.GREEN);
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                sendTitle(p, title, sub, 0, 25, 5);
            }
        }
        for (UUID id : hunters) {
            ServerPlayerEntity p = player(id);
            if (p == null) continue;
            if (prepTicksLeft % 10 == 0) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 255, false, false, false));
            }
            Vec3d f = frozenPos.computeIfAbsent(id, k -> p.getPos());
            double dx = p.getX() - f.x;
            double dz = p.getZ() - f.z;
            if (dx * dx + dz * dz > 0.25) {
                p.networkHandler.requestTeleport(f.x, p.getY(), f.z, p.getYaw(), p.getPitch());
            }
        }
        prepTicksLeft--;
    }

    private void tickGame() {
        gameTicks++;
        if (gameTicks % 5 == 0) {
            for (ServerPlayerEntity p : aliveRunnerPlayers()) {
                lastLocations.put(p.getUuid(), GlobalPos.create(p.getServerWorld().getRegistryKey(), p.getBlockPos()));
            }
        }
        if (gameTicks % 10 == 0) {
            for (UUID id : hunters) {
                ServerPlayerEntity h = player(id);
                if (h != null) refreshHunterCompass(h);
            }
        }
        if (gameTicks % 20 == 0) {
            if (timerBar != null) timerBar.setName(timerText(gameTicks / 20));
            checkAdvancementGoal();
        }
    }

    private void checkAdvancementGoal() {
        if (!"advancement".equals(config.goal) || config.advancementGoal == null || config.advancementGoal.isEmpty()) return;
        Identifier id = Identifier.tryParse(config.advancementGoal);
        if (id == null) return;
        AdvancementEntry entry = server.getAdvancementLoader().get(id);
        if (entry == null) return;
        for (ServerPlayerEntity p : aliveRunnerPlayers()) {
            if (p.getAdvancementTracker().getProgress(entry).isDone()) {
                win();
                return;
            }
        }
    }

    // ------------------------------------------------------------------ events

    public void onJoin(ServerPlayerEntity p) {
        if (!gameStarted) return;
        if (timerBar != null) timerBar.addPlayer(p);
        applyRoleHearts(p);
        if (hunters.contains(p.getUuid())) giveCompassToHunter(p);
    }

    public void onDeath(LivingEntity entity, DamageSource source) {
        if (!gameStarted) return;

        if (entity instanceof EnderDragonEntity) {
            if (!"dragon".equals(config.goal)) return;
            ServerPlayerEntity killer = null;
            Entity attacker = source.getAttacker();
            if (attacker instanceof ServerPlayerEntity a) killer = a;
            else if (entity.getPrimeAdversary() instanceof ServerPlayerEntity b) killer = b;
            if (killer != null && isAliveRunner(killer.getUuid())) win();
            return;
        }

        if (entity instanceof ServerPlayerEntity p && isAliveRunner(p.getUuid())) {
            deadRunners.add(p.getUuid());
            int alive = runners.size() - deadRunners.size();
            broadcast(t(lang.get("runner.died", "player", p.getName().getString(), "alive", String.valueOf(alive)),
                    Formatting.RED));
            if (alive <= 0) endGame(lang.get("game.end_runner_death"));
        }
    }

    public void onRespawn(ServerPlayerEntity oldPlayer, ServerPlayerEntity newPlayer, boolean alive) {
        if (!gameStarted) return;
        UUID id = newPlayer.getUuid();
        applyRoleHearts(newPlayer);
        if (deadRunners.contains(id)) {
            newPlayer.changeGameMode(GameMode.SPECTATOR);
        } else if (hunters.contains(id)) {
            giveCompassToHunter(newPlayer);
        }
    }

    public void onChangeWorld(ServerPlayerEntity p, ServerWorld origin, ServerWorld destination) {
        if (!gameStarted || !isAliveRunner(p.getUuid())) return;
        UUID id = p.getUuid();
        RegistryKey<World> from = origin.getRegistryKey();
        RegistryKey<World> to = destination.getRegistryKey();

        GlobalPos last = lastLocations.get(id);
        BlockPos departure = (last != null && last.dimension() == from) ? last.pos() : p.getBlockPos();
        portalLocations.computeIfAbsent(id, k -> new HashMap<>()).put(from, departure);

        boolean returning = !visitedWorlds.computeIfAbsent(id, k -> new HashSet<>()).add(to);
        lastLocations.put(id, GlobalPos.create(to, p.getBlockPos()));

        String name = p.getName().getString();
        Text crossed = t(lang.get("portal.crossed", "player", name, "from", dimName(from), "to", dimName(to))
                + " (" + formatLocation(departure) + ")", Formatting.YELLOW);
        Text back = returning ? t(lang.get("portal.returned", "player", name, "world", dimName(to)), Formatting.YELLOW) : null;
        for (UUID hid : hunters) {
            ServerPlayerEntity h = player(hid);
            if (h == null) continue;
            h.sendMessage(crossed, false);
            if (back != null) h.sendMessage(back, false);
        }

        if ("nether".equals(config.goal) && to == World.NETHER) win();
        else if ("end".equals(config.goal) && to == World.END) win();
    }

    public boolean onBlockBreak(World world, PlayerEntity player, BlockPos pos, BlockState state, BlockEntity be) {
        return !(gameStarted && preparationPhase && hunters.contains(player.getUuid()));
    }

    public TypedActionResult<ItemStack> onUseItem(PlayerEntity player, World world, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient || !(player instanceof ServerPlayerEntity sp)
                || !isTracker(stack) || !hunters.contains(sp.getUuid())) {
            return TypedActionResult.pass(stack);
        }
        openCompassGui(sp);
        return TypedActionResult.success(stack);
    }

    // ------------------------------------------------------------------ compass

    private static boolean isTracker(ItemStack stack) {
        if (!stack.isOf(Items.COMPASS)) return false;
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c != null && c.contains(TRACKER_TAG);
    }

    private boolean hasTracker(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (isTracker(inv.getStack(i))) return true;
        return false;
    }

    private void removeTrackers(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (isTracker(inv.getStack(i))) inv.setStack(i, ItemStack.EMPTY);
        }
    }

    private void giveCompassToHunter(ServerPlayerEntity hunter) {
        if (!hasTracker(hunter)) {
            ItemStack stack = new ItemStack(Items.COMPASS);
            NbtCompound tag = new NbtCompound();
            tag.putBoolean(TRACKER_TAG, true);
            stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
            stack.set(DataComponentTypes.CUSTOM_NAME,
                    Text.literal(lang.get("compass.item_name")).setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.RED)));
            stack.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal(lang.get("compass.item_lore")).setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.GRAY)))));
            hunter.getInventory().offerOrDrop(stack);
            hunter.sendMessage(t(lang.get("compass.received"), Formatting.GREEN), false);
        }
        refreshHunterCompass(hunter);
    }

    private void ensureHunterTarget(ServerPlayerEntity hunter) {
        UUID cur = hunterTarget.get(hunter.getUuid());
        if (cur != null && isAliveRunner(cur) && player(cur) != null) return;
        List<ServerPlayerEntity> alive = aliveRunnerPlayers();
        if (alive.isEmpty()) hunterTarget.remove(hunter.getUuid());
        else hunterTarget.put(hunter.getUuid(), alive.get(0).getUuid());
    }

    private void refreshHunterCompass(ServerPlayerEntity hunter) {
        ensureHunterTarget(hunter);
        UUID tid = hunterTarget.get(hunter.getUuid());
        ServerPlayerEntity target = tid != null ? player(tid) : null;

        RegistryKey<World> hunterWorld = hunter.getServerWorld().getRegistryKey();
        GlobalPos pos = null;
        if (target != null) {
            if (target.getServerWorld().getRegistryKey() == hunterWorld) {
                pos = GlobalPos.create(hunterWorld, target.getBlockPos());
            } else {
                Map<RegistryKey<World>, BlockPos> portals = portalLocations.get(tid);
                BlockPos p = portals != null ? portals.get(hunterWorld) : null;
                if (p != null) pos = GlobalPos.create(hunterWorld, p);
            }
        }

        Text name = target != null
                ? Text.literal(lang.get("compass.name", "player", target.getName().getString()))
                        .setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.RED))
                : Text.literal(lang.get("compass.item_name"))
                        .setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.RED));
        LodestoneTrackerComponent tracker = new LodestoneTrackerComponent(Optional.ofNullable(pos), false);

        PlayerInventory inv = hunter.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (!isTracker(stack)) continue;
            stack.set(DataComponentTypes.LODESTONE_TRACKER, tracker);
            if (!name.equals(stack.get(DataComponentTypes.CUSTOM_NAME))) {
                stack.set(DataComponentTypes.CUSTOM_NAME, name);
            }
        }
    }

    public void openCompassGui(ServerPlayerEntity hunter) {
        List<ServerPlayerEntity> alive = aliveRunnerPlayers();
        if (alive.isEmpty()) {
            hunter.sendMessage(t(lang.get("compass.no_runners"), Formatting.RED), false);
            return;
        }
        SimpleInventory inv = new SimpleInventory(27);
        List<UUID> targets = new ArrayList<>();
        for (int i = 0; i < alive.size() && i < 27; i++) {
            ServerPlayerEntity r = alive.get(i);
            ItemStack head = new ItemStack(Items.PLAYER_HEAD);
            head.set(DataComponentTypes.PROFILE, new ProfileComponent(r.getGameProfile()));
            head.set(DataComponentTypes.CUSTOM_NAME,
                    Text.literal(lang.get("compass.gui_entry", "player", r.getName().getString()))
                            .setStyle(Style.EMPTY.withItalic(false).withColor(Formatting.AQUA)));
            inv.setStack(i, head);
            targets.add(r.getUuid());
        }
        hunter.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInv, p) -> new CompassGui(syncId, playerInv, inv, targets, this::pickTarget),
                t(lang.get("compass.gui_title"), Formatting.DARK_RED)));
    }

    private void pickTarget(ServerPlayerEntity hunter, UUID target) {
        if (!isAliveRunner(target)) return;
        hunterTarget.put(hunter.getUuid(), target);
        hunter.sendMessage(t(lang.get("compass.target_set", "player", nameOf(target)), Formatting.GREEN), false);
        refreshHunterCompass(hunter);
    }

    // ------------------------------------------------------------------ settings text

    public Text settingsHeader() {
        return t(lang.get("setup.header"), Formatting.GOLD);
    }

    public Text settingsCurrent() {
        return t(lang.get("setup.current",
                "goal", "advancement".equals(config.goal) && !config.advancementGoal.isEmpty()
                        ? config.goal + " (" + config.advancementGoal + ")" : config.goal,
                "prep", String.valueOf(config.prepTime),
                "runner_hearts", trim(config.runnerHearts / 2.0),
                "hunter_hearts", trim(config.hunterHearts / 2.0)), Formatting.AQUA);
    }

    public static String trim(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
    }
}
