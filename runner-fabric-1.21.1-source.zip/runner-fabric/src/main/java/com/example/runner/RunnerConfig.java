package com.example.runner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Equivalent of the plugin's config.yml, stored as config/runner.json. */
public class RunnerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** ru | en */
    public String language = "ru";

    @SerializedName("prep-time")
    public int prepTime = 30;

    /** dragon | nether | end | advancement */
    public String goal = "dragon";

    /** e.g. minecraft:story/enter_the_end (used when goal = advancement) */
    @SerializedName("advancement-goal")
    public String advancementGoal = "";

    /** Max health in HP (1 heart = 2 HP). */
    @SerializedName("runner-hearts")
    public double runnerHearts = 20.0;

    @SerializedName("hunter-hearts")
    public double hunterHearts = 20.0;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("runner.json");
    }

    public static RunnerConfig load() {
        Path p = path();
        if (Files.exists(p)) {
            try {
                RunnerConfig c = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), RunnerConfig.class);
                if (c != null) return c;
            } catch (Exception e) {
                RunnerMod.LOGGER.error("Failed to read runner.json, using defaults", e);
            }
        }
        RunnerConfig c = new RunnerConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException e) {
            RunnerMod.LOGGER.error("Failed to save runner.json", e);
        }
    }
}
