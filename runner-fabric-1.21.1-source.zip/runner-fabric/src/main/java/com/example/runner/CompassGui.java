package com.example.runner;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;
import java.util.function.BiConsumer;

/** Server-side chest GUI ("Choose Target"). Vanilla clients can use it without the mod. */
public class CompassGui extends GenericContainerScreenHandler {
    private final List<UUID> slotTargets;
    private final BiConsumer<ServerPlayerEntity, UUID> onPick;

    public CompassGui(int syncId, PlayerInventory playerInventory, Inventory inventory,
                      List<UUID> slotTargets, BiConsumer<ServerPlayerEntity, UUID> onPick) {
        super(ScreenHandlerType.GENERIC_9X3, syncId, playerInventory, inventory, 3);
        this.slotTargets = slotTargets;
        this.onPick = onPick;
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        // Never call super: items in this GUI must not be moved.
        if (slotIndex >= 0 && slotIndex < slotTargets.size() && player instanceof ServerPlayerEntity sp) {
            UUID target = slotTargets.get(slotIndex);
            if (target != null) {
                onPick.accept(sp, target);
                sp.closeHandledScreen();
            }
        }
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }
}
